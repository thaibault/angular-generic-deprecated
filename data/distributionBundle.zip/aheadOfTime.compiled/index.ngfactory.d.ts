import * as i0 from '@angular/core';
import * as i1 from './index';
export declare const ModuleNgFactory: i0.NgModuleFactory<i1.Module>;
